﻿using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StellarInStore.Classes
{
    public class DatabaseInterface
    {
        private static SqlConnection connection;

        public static Boolean script(string sql, string connectionString)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                command.Prepare();
                dataReader = command.ExecuteReader();
                dataReader.Close();
                command.Dispose();
                connection.Close();
                return true;
            }
        }
        public static object[] sql_query(string sql, string connectionString)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            //connectionString = "Data Source = localhost; Initial Catalog = BWL_CouponServices; User ID = sa; Password =";
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                command.Prepare();
                dataReader = command.ExecuteReader();
                List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
                while (dataReader.Read())
                {
                    Dictionary<string, object> item = new Dictionary<string, object>();
                    for (var i = 0; i < dataReader.FieldCount; i++)
                    {
                        item[dataReader.GetName(i)] = dataReader.GetValue(i);
                    }

                    list.Add(item);
                }

                dataReader.Close();
                command.Dispose();
                connection.Close();
                return list.ToArray();
            }

        }

        public static object[] sql_Insert(string sql, string connectionString)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            //string connectionString = "Data Source = localhost; Initial Catalog = BWL_CouponServices; User ID = sa; Password =";
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                command.Prepare();
                dataReader = command.ExecuteReader();
                List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
                while (dataReader.Read())
                {
                    Dictionary<string, object> item = new Dictionary<string, object>();
                    for (var i = 0; i < dataReader.FieldCount; i++)
                    {
                        item[dataReader.GetName(i)] = dataReader.GetValue(i);
                    }

                    list.Add(item);
                }

                dataReader.Close();
                command.Dispose();
                connection.Close();

                return list.ToArray();
            }

        }
        public static Boolean sql_UD(string sql, string connectionString)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            //string connectionString = "Data Source = localhost; Initial Catalog = BWL_CouponServices; User ID = sa; Password =";
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();

                command = new SqlCommand(sql, connection);
                command.Prepare();
                dataReader = command.ExecuteReader();

                if (dataReader.RecordsAffected > 0)
                {
                    return true;
                }

                dataReader.Close();
                command.Dispose();
                connection.Close();

                return false;
            }

        }

        public static String connected(string connectionString)
        {
            //string connectionString = "Data Source = localhost; Initial Catalog = BWL_CouponServices; User ID = sa; Password =";
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();
                var response = connection.State;
                connection.Close();
                return response.ToString();
            }

        }

        public static object sql_queryJSON(string sql, string connectionString)
        {
            SqlCommand command;
            SqlDataReader dataReader;
            //connectionString = "Data Source = localhost; Initial Catalog = BWL_CouponServices; User ID = sa; Password =";
            using (connection = new SqlConnection(connectionString))
            {
                connection.Open();
                command = new SqlCommand(sql, connection);
                command.Prepare();
                dataReader = command.ExecuteReader();

                var jsonResult = new StringBuilder();

                if (!dataReader.HasRows)
                {
                    jsonResult.Append("[]");
                }
                else
                {
                    while (dataReader.Read())
                    {
                        jsonResult.Append(dataReader.GetValue(0).ToString());
                    }
                }

                object jsonString = JsonConvert.DeserializeObject(jsonResult.ToString());

                dataReader.Close();
                command.Dispose();
                connection.Close();
                return jsonString;
            }
        }
    }
}
