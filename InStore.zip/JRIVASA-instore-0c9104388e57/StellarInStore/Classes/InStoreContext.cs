﻿using Microsoft.EntityFrameworkCore;

using StellarInStore.Models;
namespace StellarInStore.Classes
{
    public partial class InStoreContext : DbContext
    {
        public InStoreContext(DbContextOptions<InStoreContext> data) : base(data)
        {
        }

        public DbSet<Cart> Carts{ get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<CartToken> CartTokens { get; set; }
        public DbSet<TransactionsLog> TransactionsLogs { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Sector> Sectors{ get; set; }
        public DbSet<City> Cities{ get; set; }
        public DbSet<State> States { get; set; }
        public DbSet<Country> Countries{ get; set; }
        public DbSet<ContactInfo> ContactInfos { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Product> Products { get; set; }
        public virtual DbSet<MA_DEPARTAMENTO> MA_DEPARTAMENTOs { get; set; }
        public virtual DbSet<MA_GRUPO> MA_GRUPOs { get; set; }
        public virtual DbSet<MA_MONEDA> MA_MONEDAs { get; set; }
        public virtual DbSet<MA_SUBGRUPO> MA_SUBGRUPOs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=HP17; Database=VAD10_CORP; user=sa; password=SAPB1Admin;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<MA_DEPARTAMENTO>(entity =>
            {
                entity.HasKey(e => new { e.C_CODIGO, e.C_DESCRIPCIO });

                entity.ToTable("MA_DEPARTAMENTOS");

                entity.Property(e => e.C_CODIGO).HasMaxLength(10);

                entity.Property(e => e.C_DESCRIPCIO).HasMaxLength(50);

                entity.Property(e => e.C_GRUPO)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasDefaultValueSql("(' ')");

                entity.Property(e => e.C_OBSERVACIO)
                    .IsRequired()
                    .HasColumnType("ntext")
                    .HasDefaultValueSql("(' ')");

                entity.Property(e => e.ID)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<MA_GRUPO>(entity =>
            {
                entity.HasKey(e => new { e.c_CODIGO, e.c_departamento })
                    .IsClustered(false);

                entity.ToTable("MA_GRUPOS");

                entity.Property(e => e.c_CODIGO).HasMaxLength(10);

                entity.Property(e => e.c_departamento).HasMaxLength(10);

                entity.Property(e => e.C_DESCRIPCIO)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.C_GRUPO).HasMaxLength(100);

                entity.Property(e => e.ID)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.c_OBSERVACIO).HasColumnType("text");
            });

            modelBuilder.Entity<MA_MONEDA>(entity =>
            {
                entity.HasKey(e => e.c_codmoneda)
                    .IsClustered(false);

                entity.ToTable("MA_MONEDAS");

                entity.Property(e => e.c_codmoneda).HasMaxLength(10);

                entity.Property(e => e.CodigoISO)
                    .IsRequired()
                    .HasMaxLength(20)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.bUsoEnPOS)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.b_activa)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.c_descripcion)
                    .IsRequired()
                    .HasMaxLength(25)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.c_observacio)
                    .IsRequired()
                    .HasMaxLength(250)
                    .HasDefaultValueSql("(' ')");

                entity.Property(e => e.c_simbolo)
                    .IsRequired()
                    .HasMaxLength(5)
                    .HasDefaultValueSql("(' ')");

                entity.Property(e => e.n_decimales).HasDefaultValueSql("((2))");
            });

            modelBuilder.Entity<MA_SUBGRUPO>(entity =>
            {
                entity.HasKey(e => new { e.c_CODIGO, e.c_in_grupo, e.c_in_departamento })
                    .IsClustered(false);

                entity.ToTable("MA_SUBGRUPOS");

                entity.Property(e => e.c_CODIGO).HasMaxLength(10);

                entity.Property(e => e.c_in_grupo).HasMaxLength(10);

                entity.Property(e => e.c_in_departamento).HasMaxLength(10);

                entity.Property(e => e.ID)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.c_DESCRIPCIO)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.c_GRUPO)
                    .IsRequired()
                    .HasMaxLength(100)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.c_OBSERVACIO)
                    .IsRequired()
                    .HasColumnType("ntext")
                    .HasDefaultValueSql("('')");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);


    }
}
