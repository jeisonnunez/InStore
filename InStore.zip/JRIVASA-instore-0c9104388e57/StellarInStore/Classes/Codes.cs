﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Classes
{
    public class Codes
    {
        public string c_CodNasa { get; set; }
        public string c_Codigo { get; set; }
        public string c_Descripcion { get; set; }
        public int nu_Intercambio { get; set; }
        public int nu_TipoPrecio { get; set; }
    }
}
