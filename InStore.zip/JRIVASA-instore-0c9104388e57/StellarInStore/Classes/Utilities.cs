﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace StellarInStore.Classes
{
    public class Utilities
    {
        public static string getConnectionStringByWorkingMode(IConfiguration configuration)
        {
            string workingMode = configuration.GetSection("WorkingMode").Value;
            if (!String.IsNullOrEmpty(workingMode))
            {
                return workingMode.Equals("STORE") ? configuration.GetConnectionString("StoreConnection") : configuration.GetConnectionString("WebConnection");
            }
            return null;            
        }
    }
}
