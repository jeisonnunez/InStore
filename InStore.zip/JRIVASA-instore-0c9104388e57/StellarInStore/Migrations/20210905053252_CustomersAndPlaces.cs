﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace StellarInStore.Migrations
{
    public partial class CustomersAndPlaces : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "ItemPrice",
                table: "CartItems",
                type: "float",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.CreateTable(
                name: "Addresses",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryId = table.Column<int>(type: "int", nullable: false),
                    StateId = table.Column<int>(type: "int", nullable: false),
                    CityId = table.Column<int>(type: "int", nullable: true),
                    SectorId = table.Column<int>(type: "int", nullable: true),
                    ZipCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddressLine = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AddressLine2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OwnerCode = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Default = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Addresses", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "Cities",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShortName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CityId = table.Column<int>(type: "int", nullable: false),
                    Capital = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cities", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "ContactInfos",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OwnerCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Default = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContactInfos", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ISO = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Active = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Code = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Lastname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReceivePromos = table.Column<bool>(type: "bit", nullable: false),
                    PriceType = table.Column<int>(type: "int", nullable: false),
                    DefaultBranch = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<int>(type: "int", nullable: false),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HashActivation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RegistryDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Birthdate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Identification = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    c_Codigo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Descri = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Departamento = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Grupo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Subgrupo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Marca = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Modelo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    n_Precio1 = table.Column<double>(type: "float", nullable: false),
                    n_Precio2 = table.Column<double>(type: "float", nullable: false),
                    n_Precio3 = table.Column<double>(type: "float", nullable: false),
                    n_Peso = table.Column<double>(type: "float", nullable: false),
                    n_CantiBul = table.Column<double>(type: "float", nullable: false),
                    n_PesoBul = table.Column<double>(type: "float", nullable: false),
                    n_VolBul = table.Column<double>(type: "float", nullable: false),
                    n_Impuesto1 = table.Column<float>(type: "real", nullable: false),
                    n_Impuesto2 = table.Column<float>(type: "real", nullable: false),
                    n_Impuesto3 = table.Column<float>(type: "real", nullable: false),
                    n_Activo = table.Column<int>(type: "int", nullable: false),
                    n_TipoPeso = table.Column<int>(type: "int", nullable: false),
                    n_PrecioO = table.Column<double>(type: "float", nullable: false),
                    f_Inicial = table.Column<DateTime>(type: "datetime2", nullable: false),
                    f_Final = table.Column<DateTime>(type: "datetime2", nullable: false),
                    h_Inicial = table.Column<DateTime>(type: "datetime2", nullable: false),
                    h_Final = table.Column<DateTime>(type: "datetime2", nullable: false),
                    c_CodMoneda = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cant_Decimales = table.Column<int>(type: "int", nullable: false),
                    c_Codigo_Base = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    c_Descri_Base = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text3 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text4 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text5 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text6 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text7 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Text8 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "Sectors",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CityId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sectors", x => x.AutoID);
                });

            migrationBuilder.CreateTable(
                name: "States",
                columns: table => new
                {
                    AutoID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShortName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CountryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_States", x => x.AutoID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Addresses");

            migrationBuilder.DropTable(
                name: "Cities");

            migrationBuilder.DropTable(
                name: "ContactInfos");

            migrationBuilder.DropTable(
                name: "Countries");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Products");

            migrationBuilder.DropTable(
                name: "Sectors");

            migrationBuilder.DropTable(
                name: "States");

            migrationBuilder.DropColumn(
                name: "ItemPrice",
                table: "CartItems");
        }
    }
}
