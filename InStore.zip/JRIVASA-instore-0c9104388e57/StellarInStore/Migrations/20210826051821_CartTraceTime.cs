﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace StellarInStore.Migrations
{
    public partial class CartTraceTime : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "ClosureDate",
                table: "Carts",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "RequestedDate",
                table: "Carts",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "status",
                table: "Carts",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClosureDate",
                table: "Carts");

            migrationBuilder.DropColumn(
                name: "RequestedDate",
                table: "Carts");

            migrationBuilder.DropColumn(
                name: "status",
                table: "Carts");
        }
    }
}
