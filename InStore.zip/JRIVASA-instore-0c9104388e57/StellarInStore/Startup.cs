using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;

namespace StellarInStore
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<Classes.InStoreContext>(
                options => options.UseSqlServer(
                    Configuration.GetConnectionString("StoreConnection")
                    )
                );
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddTransient<Classes.InStoreContext>();
            services.AddMvc(options =>
            {
                options.RespectBrowserAcceptHeader = true; // false by default
            });
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddControllers().AddNewtonsoftJson();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            using (var serviceScope = app.ApplicationServices.GetService<IServiceScopeFactory>().CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<StellarInStore.Classes.InStoreContext>();
                context.Database.Migrate();
            }

            app.UseStatusCodePages(async context =>
            {
                if (context.HttpContext.Response.StatusCode == 401 ||
                    context.HttpContext.Response.StatusCode == 400 ||
                    context.HttpContext.Response.StatusCode == 404 ||
                    context.HttpContext.Response.StatusCode == 500 ||
                    context.HttpContext.Response.StatusCode == 405)
                {
                    context.HttpContext.Response.ContentType = "application/json";
                    await context.HttpContext.Response.WriteAsync(text: JsonConvert.SerializeObject(new
                    {
                        status = "error",
                        status_code = 100,
                        message = "Error " + context.HttpContext.Response.StatusCode,
                        datetime = System.DateTime.Now
                    },
                   Formatting.Indented));
                }
            });
        }
    }
}
