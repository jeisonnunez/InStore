﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Models
{
    public class TransactionsLog
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoId { get; set; }
        public string TransactionId { get; set; }
        public int TransactionType { get; set; }
        public int TransactionResult { get; set; }
        public DateTime TransactionDate { get; set; } = System.DateTime.Now;
        public string RequestOrigin { get; set; }
        public string Observation { get; set; }

        public static TransactionsLog prepareLogObject(string cartOrigin, int transactionType)
        {
            var transactionInformation = new TransactionsLog();
            transactionInformation.TransactionType = transactionType;
            transactionInformation.RequestOrigin = !string.IsNullOrEmpty(cartOrigin) ? cartOrigin : "not set"; ;
            transactionInformation.TransactionId = "NA";
            return transactionInformation;
        }

    }
}
