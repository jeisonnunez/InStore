﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Models
{
    public class ContactInfo
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoID { get; set; }
        public int Type { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }
        public string OwnerCode { get; set; }
        public int Status { get; set; }
        public bool Default { get; set; }
    }
}
