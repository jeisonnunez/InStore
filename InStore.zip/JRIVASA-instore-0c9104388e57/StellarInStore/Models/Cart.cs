﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StellarInStore.Models
{
    public class Cart
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoId { get; set; }
        public string CartToken { get; set; }
        public string ClientIdentification { get; set; }
        public string CartOrigin { get; set; }
        public DateTime CreationDate { get; set; } = DateTime.Now;
        public DateTime? RequestedDate { get; set; }
        public DateTime? ClosureDate { get; set; }
        public int status { get; set; } = 1;//1: Prepared, 2: Requested, 3: Procesed
        [NotMapped]
        public List<CartItem> CartList { get; set; }

        public static Cart loadFromDatabase(Classes.InStoreContext context, string cartToken)
        {
            //Load Cart main information
            var dbCart = context.Carts.Where(c=> c.CartToken == cartToken).ToList();
            Cart newCart = dbCart[0];
            if (newCart != null)
            {
                //Load items
                newCart.CartList = context.CartItems.Where(c => c.CartToken == cartToken).ToList();
            }
            return newCart;
        }
    }

    
}
