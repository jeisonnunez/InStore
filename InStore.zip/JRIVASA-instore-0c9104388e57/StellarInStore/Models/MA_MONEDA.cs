﻿using System;
using System.Collections.Generic;

#nullable disable

namespace StellarInStore.Models
{
    public partial class MA_MONEDA
    {
        public string c_codmoneda { get; set; }
        public string c_descripcion { get; set; }
        public double n_factor { get; set; }
        public bool b_preferencia { get; set; }
        public string c_observacio { get; set; }
        public bool? b_activa { get; set; }
        public string c_simbolo { get; set; }
        public int n_decimales { get; set; }
        public bool? bUsoEnPOS { get; set; }
        public string CodigoISO { get; set; }
    }
}
