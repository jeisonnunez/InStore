﻿using System;
using System.Collections.Generic;

#nullable disable

namespace StellarInStore.Models
{
    public partial class MA_GRUPO
    {
        public string c_CODIGO { get; set; }
        public string C_DESCRIPCIO { get; set; }
        public string C_GRUPO { get; set; }
        public string c_OBSERVACIO { get; set; }
        public string c_departamento { get; set; }
        public double NU_PORCUTILIDAD { get; set; }
        public decimal ID { get; set; }
        public bool B_LIBROLICORES { get; set; }
    }
}
