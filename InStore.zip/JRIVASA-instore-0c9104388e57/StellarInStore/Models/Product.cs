﻿using StellarInStore.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Models
{
    public class Product
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoID { get; set; }
        public string c_Codigo { get; set; }
        public string c_Descri { get; set; }
        public string c_Departamento { get; set; }
        public string c_Grupo { get; set; }
        public string c_Subgrupo { get; set; }
        public string c_Marca { get; set; }
        public string c_Modelo { get; set; }
        public double n_Precio1 { get; set; }
        public double n_Precio2 { get; set; }
        public double n_Precio3 { get; set; }
        public double n_Peso { get; set; }
        public double n_CantiBul { get; set; }
        public double n_PesoBul { get; set; }
        public double n_VolBul { get; set; }
        public float n_Impuesto1 { get; set; }
        public float n_Impuesto2 { get; set; }
        public float n_Impuesto3 { get; set; }
        public int n_Activo { get; set; }
        public int n_TipoPeso { get; set; }
        public double n_PrecioO { get; set; }
        public DateTime f_Inicial { get; set; }
        public DateTime f_Final { get; set; }
        public DateTime h_Inicial { get; set; }
        public DateTime h_Final { get; set; }
        public string c_CodMoneda { get; set; }
        public int Cant_Decimales { get; set; }
        public string c_Codigo_Base { get; set; }
        public string c_Descri_Base { get; set; }
        public string Text1 { get; set; }
        public string Text2 { get; set; }
        public string Text3 { get; set; }
        public string Text4 { get; set; }
        public string Text5 { get; set; }
        public string Text6 { get; set; }
        public string Text7 { get; set; }
        public string Text8 { get; set; }
        [NotMapped]
        public bool isInOffer { get; set; }

        private static string BasicInfoConditionByCode(string productCode)
        {
            return " WHERE C.c_Codigo = '" + productCode + "' ";
        }

        private static string BasicInfoCondicionBySearchTerm(string searchTerm)
        {
            return " WHERE P.c_Descri LIKE '%" + searchTerm + "%' OR P.c_Codigo LIKE '%" + searchTerm + "%' OR P.c_Marca LIKE '%" + searchTerm + "%' OR P.c_Modelo LIKE '%" + searchTerm + "%' ";
        }

        private static string BasicInfoMultipleFilter(Product productSearchModel)
        {
            string searchFilter = " WHERE " +
                "P.c_Descri LIKE '%"+productSearchModel.c_Descri+ "%' AND " +
                "P.c_Codigo LIKE '%" + productSearchModel.c_Codigo+ "%' AND " +
                "P.c_Marca LIKE '%" + productSearchModel.c_Marca+ "%' AND " +
                "P.c_Modelo LIKE '%" + productSearchModel.c_Modelo+ "%' AND " +
                "P.c_Departamento LIKE '%" + productSearchModel.c_Departamento+ "%' AND " +
                "P.c_Grupo LIKE '%" + productSearchModel.c_Grupo+ "%' AND " +
                "P.c_Subgrupo LIKE '%" + productSearchModel.c_Subgrupo+ "%' ";
            //TODO: Agregar soporte para buscar por existencia minima y máxima
            return searchFilter;
        }

        public static string BasicInfoBodyQuery(string priceTypeString, bool convertToDefaultCurrency, bool checkCodeTable)
        {
            String fieldMultiplier = convertToDefaultCurrency ? " * isNULL(CASE WHEN MON.n_Factor <> 0 THEN MON.n_Factor ELSE 1 END, 1)"
                : " ";
            string codeTable = checkCodeTable ? " INNER JOIN MA_CODIGOS C ON P.c_Codigo = C.c_CodNasa  " : " ";
            string cCantidad = checkCodeTable ? " C.n_cantidad " : " 1 ";
            string codeTableInfo = checkCodeTable ? " C.nu_Intercambio as intercambio, C.c_Codigo as CodigoIntercambio, C.n_cantidad as qtyByCode ," : " ";
            return " SELECT " +
                                "P.c_Codigo, P.c_Descri, P.n_Impuesto1, " +
                                "((P." + priceTypeString + " " + fieldMultiplier + " ) * "+ cCantidad +") AS Precio1,  " +
                                "((P.n_PrecioO " + fieldMultiplier + " ) * " + cCantidad + ") AS PrecioOf,  " +
                                "(((P." + priceTypeString + " " + fieldMultiplier + " ) * " + cCantidad + ") * (P.n_Impuesto1 / 100)) AS IVA,  " +
                                "(((P." + priceTypeString + " " + fieldMultiplier + " ) * " + cCantidad + ") * (1 + (P.n_Impuesto1 / 100))) AS TotalGral,  " +
                                "((P.n_PrecioO " + fieldMultiplier + " ) * (1 + (P.n_Impuesto1 / 100))) AS TotalOf,  " +
                                "P.f_Inicial, P.f_Final, P.h_Inicial, P.h_Final,  " +
                                "P.c_CodMoneda, isNULL(MON.c_Descripcion, 'N/A') AS c_MonedaDesc,  " +
                                "isNULL(MON.c_Simbolo, '') AS c_MonedaSimbolo,  " +
                                "isNULL(MON.n_Factor, 1) AS n_Factor,  " +
                                "isNULL(MON.n_decimales, 2) AS n_Decimales," +
                                "p." + priceTypeString + " AS PrecioFicha, p.n_PrecioO AS PrecioOfertaFicha, " +
                                " "+ codeTableInfo +" P.n_CantiBul as packQty, " +
                                "P.c_Departamento, P.c_Grupo, P.c_Subgrupo, P.c_Marca, P.c_Modelo " +
                              "FROM MA_PRODUCTOS P  " +
                              codeTable + 
                              "LEFT JOIN [VAD10].[DBO].[MA_MONEDAS] MON ON P.c_CodMoneda = MON.c_CodMoneda  ";
        }

        public static string ProductBasicInfoQueryByCode(string priceTypeString, bool convertToDefaultCurrency, string productCode)
        {
            return BasicInfoBodyQuery(priceTypeString, convertToDefaultCurrency, true) +  BasicInfoConditionByCode(productCode);
        }

        public static string ProductBasicInfoQueryBySearchTerm(string priceTypeString, bool convertToDefaultCurrency, string searchTerm)
        {
            return BasicInfoBodyQuery(priceTypeString, convertToDefaultCurrency, false) + BasicInfoCondicionBySearchTerm(searchTerm);
        }

        public static string ProductBasicInfoQueryMultifilter(string priceTypeString, bool convertToDefaultCurrency, Product productModelSearch)
        {
            return BasicInfoBodyQuery(priceTypeString, convertToDefaultCurrency, false) + BasicInfoMultipleFilter(productModelSearch);
        }

        public static string productPriceType(string conString, string productCode)
        {
            var priceTypeQuery = "SELECT CAST(MC.nu_TipoPrecio as varchar(10)) as columnName FROM MA_CODIGOS MC WHERE MC.c_Codigo = '" + productCode + "'";
            var priceTypeData = DatabaseInterface.sql_query(priceTypeQuery, conString);
            var priceTypeString = "";
            if (priceTypeData.Length > 0)
            {
                foreach (Dictionary<string, object> kvp in priceTypeData)
                {
                    var element = kvp.ElementAt(0);
                    String priceTypeValue = element.Value.ToString();
                    priceTypeValue = priceTypeValue == "0" ? "1" : priceTypeValue;
                    priceTypeString = "n_Precio" + priceTypeValue;
                }
            }
            else
            {
                priceTypeString = "n_Precio1";
            }
            return priceTypeString;
        }
    }
}
