﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Models
{
    public class Address
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoID { get; set; }
        public int CountryId { get; set; }
        public int StateId { get; set; }
        public int? CityId { get; set; }
        public int? SectorId { get; set; }
        public string ZipCode { get; set; }
        public string AddressLine { get; set; } = "";
        public string AddressLine2 { get; set; } = "";
        public int OwnerCode { get; set; }
        public int Status { get; set; }
        public bool Default { get; set; } = false;

    }
}
