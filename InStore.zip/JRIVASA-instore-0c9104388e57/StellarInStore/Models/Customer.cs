﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace StellarInStore.Models
{
    public class Customer
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoID { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public bool ReceivePromos { get; set; }
        public int PriceType { get; set; }
        public string DefaultBranch { get; set; }
        public int Status { get; set; }
        public string Gender { get; set; }
        public string HashActivation { get; set; }
        public DateTime RegistryDate { get; set; }
        public DateTime Birthdate { get; set; }
        public string Identification { get; set; }
        [NotMapped]
        public List<Address> AddressBook { get; set; }
        [NotMapped]
        public List<ContactInfo> ContactBook { get; set; }


    }
}
