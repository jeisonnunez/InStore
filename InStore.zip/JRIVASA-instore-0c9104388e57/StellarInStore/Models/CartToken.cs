﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using StellarInStore.Classes;
namespace StellarInStore.Models
{
    public class CartToken
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int AutoId { get; set; }
        public String Token { get; set; }
        public String RequestOrigin { get; set; }
        public int Used { get; set; }
        public DateTime CreationDate { get; set; } = System.DateTime.Now;
        public DateTime UsedDate { get; set; } = System.DateTime.Now;
        
        public String getToken(InStoreContext context, string requestOrigin)
        {
            //Get an available token
            String returnedToken = null;
            var auxToken = context.CartTokens.FirstOrDefault(c => (c.Used == 0));
            if (auxToken != null)
            {
                //Token to be return
                returnedToken = auxToken.Token.ToString();
                auxToken.Used = 1;
                auxToken.RequestOrigin = requestOrigin;
                auxToken.UsedDate = System.DateTime.Now;
                context.Update(auxToken);
            }
            else
            {
                //If not token available, create one and reserve it
                this.RequestOrigin = requestOrigin;
                this.Used = 1;
                this.generateAndSaveToken(context);
                returnedToken = this.Token;
            }
            context.SaveChanges();
            return returnedToken;
        }

        public static void reserveTokens(InStoreContext context, int count)
        {
            Console.WriteLine("Start reserving " + count.ToString() + " tokens");
            for (int i = 0; i < count; i++)
            {
                CartToken cartToken= new CartToken();
                cartToken.RequestOrigin = "pending";
                cartToken.Used = 0;
                cartToken.CreationDate = System.DateTime.Now;
                cartToken.UsedDate = System.DateTime.Now;
                cartToken.generateAndSaveToken(context);
            }
            Console.WriteLine("... done");
        }

        private bool generateAndSaveToken(InStoreContext context)
        {
            this.Token = this.generateNonRepeatedToken(context);

            context.Add(this);
            return true;
        }

        private string generateNonRepeatedToken(InStoreContext context)
        {
            bool validToken = false;
            string candidateToken = "";
            while (!validToken)
            {
                candidateToken = this.generateAndReturnToken();
                //Check if there's a token equals to the current
                var search = context.CartTokens.Where(a => a.Token == candidateToken);
                /*var search = context.TransactionToken.FirstOrDefault(
                    c => (c.Token.ToString().Equals(candidateToken)));*/
                validToken = !(search.Count() > 0);
            }
            Console.WriteLine("TOKEN: " + candidateToken);
            return candidateToken;
        }

        private string generateAndReturnToken()
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            string tokenSufix = new string(Enumerable.Repeat(chars, 6)
              .Select(s => s[random.Next(s.Length)]).ToArray());
            return tokenSufix;
        }
    }
}
