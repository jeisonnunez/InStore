﻿using System;
using System.Collections.Generic;

#nullable disable

namespace StellarInStore.Models
{
    public partial class MA_SUBGRUPO
    {
        public string c_CODIGO { get; set; }
        public string c_DESCRIPCIO { get; set; }
        public string c_GRUPO { get; set; }
        public string c_OBSERVACIO { get; set; }
        public string c_in_grupo { get; set; }
        public string c_in_departamento { get; set; }
        public double NU_PORCUTILIDAD { get; set; }
        public decimal ID { get; set; }
        public bool B_LIBROLICORES { get; set; }
    }
}
