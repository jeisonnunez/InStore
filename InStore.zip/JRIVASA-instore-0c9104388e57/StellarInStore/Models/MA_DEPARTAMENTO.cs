﻿using System;
using System.Collections.Generic;

#nullable disable

namespace StellarInStore.Models
{
    public partial class MA_DEPARTAMENTO
    {
        public string C_CODIGO { get; set; }
        public string C_DESCRIPCIO { get; set; }
        public string C_GRUPO { get; set; }
        public string C_OBSERVACIO { get; set; }
        public double NU_PORCUTILIDAD { get; set; }
        public bool B_LIBROLICORES { get; set; }
        public decimal ID { get; set; }

        public static string CategoriesQuery()
        {
            return BasicInfoBodyQuery();
        }

        public static string BasicInfoBodyQuery()
        {

            return "SELECT MA_DEPARTAMENTOS.C_CODIGO , MA_DEPARTAMENTOS.C_DESCRIPCIO  , MA_DEPARTAMENTOS.C_GRUPO      , MA_DEPARTAMENTOS.C_OBSERVACIO      , MA_DEPARTAMENTOS.NU_PORCUTILIDAD      , MA_DEPARTAMENTOS.B_LIBROLICORES      , MA_DEPARTAMENTOS.ID,      MA_GRUPOS.c_CODIGO AS 'CODIGO_G' ,   MA_GRUPOS.C_DESCRIPCIO AS 'DESCRIPCION', MA_SUBGRUPOS.c_CODIGO AS 'SUBGRUPO_COD', MA_SUBGRUPOS.c_DESCRIPCIO AS 'SUBGRUPO_DES' FROM MA_DEPARTAMENTOS LEFT JOIN MA_GRUPOS ON MA_DEPARTAMENTOS.C_CODIGO = MA_GRUPOS.c_departamento LEFT JOIN MA_SUBGRUPOS ON MA_GRUPOS.C_CODIGO = MA_SUBGRUPOS.c_in_grupo ORDER BY MA_DEPARTAMENTOS.C_CODIGO FOR JSON AUTO";
        }
    }
}
