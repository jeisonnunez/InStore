﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StellarInStore.Classes;
using StellarInStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace MVCArrayParametro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MonedaPredeterminadaController : ControllerBase
    {
        private InStoreContext inStoreContext;     
        public MonedaPredeterminadaController(InStoreContext context)
        {
            this.inStoreContext = context;
        }

        [HttpGet("DefaultCurrency")]

        public IActionResult GetCurrencyDefault()
        {
            TransactionsLog transaction = new TransactionsLog();

            try
            {
                var CurrencyDefault = this.inStoreContext.MA_MONEDAs.FirstOrDefault(
                  c => c.b_preferencia == true);


                if (CurrencyDefault == null)
                {
                    //transaction.Observation = "Not Found Currency for Default ";
                    //transaction.TransactionResult = 104; //Revisar
                    //transaction.TransactionId = "2";//Revisar
                    //this.inStoreContext.TransactionsLogs.Add(transaction);
                    //this.inStoreContext.SaveChanges();
                    //this.inStoreContext.Database.CommitTransaction();
                    //this.inStoreContext.Dispose();

                    return Ok(new
                    {
                        status = "error",
                        status_code = 103,
                        message = "Not Found Currency for default",
                        datetime = DateTime.Now
                    });
                }
                else
                {
                    //transaction.Observation = "Currency For Default Success";
                    //transaction.TransactionResult = 104; //Revisar
                    //transaction.TransactionId = "2";//Revisar
                    //this.inStoreContext.TransactionsLogs.Add(transaction);
                    //this.inStoreContext.SaveChanges();
                    //this.inStoreContext.Database.CommitTransaction();
                    //this.inStoreContext.Dispose();

                    return Ok(new
                    {
                        status = "success",
                        message = "Currency For Default Success",
                        data = CurrencyDefault.c_descripcion,
                        CurrencyDefault.n_factor,
                        datetime = DateTime.Now,
                        status_code = 00.ToString("D2")
                    });
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                //transaction.TransactionId = CartToken;
                //this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }

        }

        [HttpGet("SelectedCurrency")]
        public IActionResult GetCurrencySelected(MA_MONEDA c_codmoneda)
        {
            TransactionsLog transaction = new TransactionsLog();

            try
            {
                var CurrencySelected = this.inStoreContext.MA_MONEDAs.FirstOrDefault(
                    u => u.c_codmoneda == c_codmoneda.c_codmoneda);

                if (CurrencySelected == null)
                {
                    //transaction.Observation = "Not Found Currency Selected ";
                    //transaction.TransactionResult = 104; //Revisar
                    //transaction.TransactionId = "2";//Revisar
                    //this.inStoreContext.TransactionsLogs.Add(transaction);
                    //this.inStoreContext.SaveChanges();
                    //this.inStoreContext.Database.CommitTransaction();
                    //this.inStoreContext.Dispose();

                    return Ok(new
                    {
                        status = "error",
                        status_code = 103,
                        message = "Not Found Selected Currency",
                        datetime = DateTime.Now
                    });
                }
                else
                {
                    //transaction.Observation = "Currency Selected Success";
                    //transaction.TransactionResult = 104; //Revisar
                    //transaction.TransactionId = "2";//Revisar
                    //this.inStoreContext.TransactionsLogs.Add(transaction);
                    //this.inStoreContext.SaveChanges();
                    //this.inStoreContext.Database.CommitTransaction();
                    //this.inStoreContext.Dispose();

                    return Ok(new
                    {
                        status = "success",
                        message = "Currency Selected",
                        data = CurrencySelected.c_descripcion,
                        CurrencySelected.n_factor,
                        datetime = DateTime.Now,
                        status_code = 00.ToString("D2")
                    });
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                //transaction.TransactionId = CartToken;
                //this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }

        }


    }
}
