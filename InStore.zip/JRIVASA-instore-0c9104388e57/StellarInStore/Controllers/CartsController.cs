﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StellarInStore.Models;
using StellarInStore.Classes;
using Microsoft.AspNetCore.Http;

namespace StellarInStore.Controllers
{
    [Route("api/carts")]
    [ApiController]
    public class CartsController : ControllerBase
    {
        private InStoreContext inStoreContext;
        public CartsController(InStoreContext context)
        {
            this.inStoreContext = context;
        }

        [HttpPost("[action]")]
        public IActionResult SaveCart([FromBody] Cart data)
        {
            
            TransactionsLog transaction = TransactionsLog.prepareLogObject(data.CartOrigin, 1);//Save Cart
            Console.WriteLine("Incoming request for saving a cart " + System.DateTime.Now);
            this.inStoreContext.Database.BeginTransaction();
            //Prepare a token to be returned
            CartToken cartToken = new CartToken();
            string cartTokenValue = cartToken.getToken(inStoreContext, data.CartOrigin);
            this.inStoreContext.Database.CommitTransaction();
            this.inStoreContext.Database.BeginTransaction();
            //Asign token to cart
            data.CartToken = cartTokenValue;
            //Save cart in database
            this.inStoreContext.Carts.Add(data);
            //Save items
            for (int i = 0, count = data.CartList.Count(); i < count; i++)
            {
                CartItem cartItem = data.CartList[i];
                cartItem.CartToken = cartTokenValue;
                //TODO: Check if description is coming from request
                this.inStoreContext.CartItems.Add(cartItem);
                Console.WriteLine("Add item to cart, code: "+cartItem.ProductCode+" - Qty: "+cartItem.Quantity);
            }
            //Try to save the changes
            try
            {
                Console.WriteLine("Cart saved with token: " + cartTokenValue + ". Items in cart: " + data.CartList.Count());
                transaction.Observation = "Cart saved with token: "+cartTokenValue+". Items in cart: "+data.CartList.Count();
                transaction.TransactionResult = 200;//OK
                transaction.TransactionId = cartTokenValue;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                Console.WriteLine("End request at "+DateTime.Now);
                return Ok(
                    new { 
                        status = "success", 
                        message = "Cart saved!", 
                        token = cartTokenValue, 
                        datetime = DateTime.Now, 
                    status_code = 00.ToString("D2") });
            }
            catch(Exception ex)
            {
                this.inStoreContext.Database.RollbackTransaction();
                transaction.Observation = "Exception Catched, message: " + ex.InnerException.Message;
                transaction.TransactionResult = 500;
                transaction.TransactionId = cartTokenValue;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                Console.WriteLine("End request at " + DateTime.Now + " with failure.");
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }
        }

        [HttpGet("[action]/{CartToken}")]
        public IActionResult GetCart(string CartToken)
        {
            string request = Request.Headers["User-Agent"].ToString();
            TransactionsLog transaction = TransactionsLog.prepareLogObject(request, 2);//Retrieve Cart
            Console.WriteLine("Incoming request for retrieve a cart " + DateTime.Now);
            var cart = this.inStoreContext.Carts.Where(c => c.CartToken == CartToken).ToList();
            var cartItems = this.inStoreContext.CartItems.Where(c => c.CartToken == CartToken).ToList();
            Cart result;
            this.inStoreContext.Database.BeginTransaction();
            try
            {
                if (cart.Count() > 0)
                {
                    Console.WriteLine("Cart found...");
                    result = cart[0];
                    if (cartItems.Count() > 0)
                    {
                        if (result.status == 2 || result.status == 3)
                        {
                            Console.WriteLine("Cart is taken, aborting...");
                            transaction.Observation = "Cart found but taken, release first, code: " + CartToken;
                            transaction.TransactionResult = 103;
                            transaction.TransactionId = CartToken;
                            this.inStoreContext.TransactionsLogs.Add(transaction);
                            this.inStoreContext.SaveChanges();
                            this.inStoreContext.Database.CommitTransaction();
                            this.inStoreContext.Dispose();
                            return Ok(new
                            {
                                status = "error",
                                status_code = 103,
                                message = "Cart taken",
                                datetime = DateTime.Now
                            });
                        }
                        else
                        {
                            result.CartList = cartItems;
                            Console.WriteLine("Items in cart: " + cartItems.Count());
                            Console.WriteLine("End request at " + DateTime.Now);
                            result.status = 2;
                            result.RequestedDate = DateTime.Now;
                            transaction.Observation = "Cart found and returned, code: " + CartToken;
                            transaction.TransactionResult = 200;
                            transaction.TransactionId = CartToken;
                            this.inStoreContext.Carts.Update(result);
                            this.inStoreContext.TransactionsLogs.Add(transaction);
                            this.inStoreContext.SaveChanges();
                            this.inStoreContext.Database.CommitTransaction();
                            this.inStoreContext.Dispose();
                            return Ok(
                            new
                            {
                                status = "success",
                                message = "Cart found",
                                data = result,
                                datetime = DateTime.Now,
                                status_code = 00.ToString("D2")
                            });
                        }
                    }
                    else
                    {
                        Console.WriteLine("Cart has no items...");
                        Console.WriteLine("End request at " + DateTime.Now);
                        transaction.Observation = "Cart found but no items, code: " + CartToken;
                        transaction.TransactionResult = 101;
                        transaction.TransactionId = CartToken;
                        this.inStoreContext.TransactionsLogs.Add(transaction);
                        this.inStoreContext.SaveChanges();
                        this.inStoreContext.Database.CommitTransaction();
                        this.inStoreContext.Dispose();
                        return Ok(new
                        {
                            status = "error",
                            status_code = 101,
                            message = "Empty cart",
                            datetime = DateTime.Now
                        });
                    }
                }
                else
                {
                    Console.WriteLine("Cart not found...");
                    Console.WriteLine("End request at " + DateTime.Now);
                    transaction.Observation = "Cart not found, code: " + CartToken;
                    transaction.TransactionResult = 102;
                    transaction.TransactionId = CartToken;
                    this.inStoreContext.TransactionsLogs.Add(transaction);
                    this.inStoreContext.SaveChanges();
                    this.inStoreContext.Database.CommitTransaction();
                    this.inStoreContext.Dispose();
                    return Ok(new
                    {
                        status = "error",
                        status_code = 102,
                        message = "Cart not found",
                        datetime = DateTime.Now
                    });
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                transaction.TransactionId = CartToken;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }
        }

        [HttpGet("[action]/{CartToken}")]
        public IActionResult CloseCart(string CartToken)
        {
            string request = Request.Headers["User-Agent"].ToString();
            TransactionsLog transaction = TransactionsLog.prepareLogObject(request, 3);//Close cart
            Console.WriteLine("Incoming request for closing a cart " + System.DateTime.Now);
            var cart = this.inStoreContext.Carts.Where(c => c.CartToken == CartToken).ToList();
            this.inStoreContext.Database.BeginTransaction();
            try
            {
                if (cart.Count() > 0)
                {
                    cart[0].status = 3;
                    cart[0].ClosureDate = DateTime.Now;
                    Console.WriteLine("Cart found, closing");
                    Console.WriteLine("End request at " + DateTime.Now);
                    transaction.Observation = "Cart closed, code: " + CartToken;
                    transaction.TransactionResult = 200;
                    transaction.TransactionId = CartToken;
                    this.inStoreContext.Carts.Update(cart[0]);
                    this.inStoreContext.TransactionsLogs.Add(transaction);
                    this.inStoreContext.SaveChanges();
                    this.inStoreContext.Database.CommitTransaction();
                    this.inStoreContext.Dispose();
                    return Ok(
                            new
                            {
                                status = "success",
                                message = "Cart closed",
                                datetime = DateTime.Now,
                                status_code = 00.ToString("D2")
                            });
                }
                else
                {
                    Console.WriteLine("Cart not found...");
                    Console.WriteLine("End request at " + DateTime.Now);
                    transaction.Observation = "Cart not found, code: " + CartToken;
                    transaction.TransactionResult = 102;
                    transaction.TransactionId = CartToken;
                    this.inStoreContext.TransactionsLogs.Add(transaction);
                    this.inStoreContext.SaveChanges();
                    this.inStoreContext.Database.CommitTransaction();
                    this.inStoreContext.Dispose();
                    return Ok(new
                    {
                        status = "error",
                        status_code = 102,
                        message = "Cart not found",
                        datetime = DateTime.Now
                    });
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                transaction.TransactionId = CartToken;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }
        }

        [HttpGet("[action]/{CartToken}")]
        public IActionResult OpenCart(string CartToken)
        {
            string request = Request.Headers["User-Agent"].ToString();
            TransactionsLog transaction = TransactionsLog.prepareLogObject(request, 4);//Open cart
            Console.WriteLine("Incoming request to open a cart " + System.DateTime.Now);
            var cart = this.inStoreContext.Carts.Where(c => c.CartToken == CartToken).ToList();
            this.inStoreContext.Database.BeginTransaction();
            try
            {
                if (cart.Count() > 0)
                {
                    cart[0].status = 1;
                    cart[0].ClosureDate = DateTime.Now;
                    Console.WriteLine("Cart found, opening...");
                    Console.WriteLine("End request at " + DateTime.Now);
                    transaction.Observation = "Cart opened, code: " + CartToken;
                    transaction.TransactionResult = 200;
                    transaction.TransactionId = CartToken;
                    this.inStoreContext.Carts.Update(cart[0]);
                    this.inStoreContext.TransactionsLogs.Add(transaction);
                    this.inStoreContext.SaveChanges();
                    this.inStoreContext.Database.CommitTransaction();
                    this.inStoreContext.Dispose();
                    return Ok(
                            new
                            {
                                status = "success",
                                message = "Cart opened",
                                datetime = DateTime.Now,
                                status_code = 00.ToString("D2")
                            });
                }
                else
                {
                    Console.WriteLine("Cart not found...");
                    Console.WriteLine("End request at " + DateTime.Now);
                    transaction.Observation = "Cart not found, code: " + CartToken;
                    transaction.TransactionResult = 103;
                    transaction.TransactionId = CartToken;
                    this.inStoreContext.TransactionsLogs.Add(transaction);
                    this.inStoreContext.SaveChanges();
                    this.inStoreContext.Database.CommitTransaction();
                    this.inStoreContext.Dispose();
                    return Ok(new
                    {
                        status = "error",
                        status_code = 102,
                        message = "Cart not found",
                        datetime = DateTime.Now
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                transaction.TransactionId = CartToken;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }
        }

        [HttpPost("[action]")]

        public IActionResult SyncCart([FromBody] Cart data)
        {

            TransactionsLog transaction = TransactionsLog.prepareLogObject(data.CartOrigin, 2);//Sync Cart
            Console.WriteLine("Incoming request for sync a cart " + System.DateTime.Now);
            Cart cartInDb = Cart.loadFromDatabase(this.inStoreContext, data.CartToken);
            this.inStoreContext.Database.BeginTransaction();
            //Update cart in database
            this.inStoreContext.Carts.Update(data);
            //Clean cart
            this.inStoreContext.CartItems.RemoveRange(cartInDb.CartList);
            //Save items
            for (int i = 0, count = data.CartList.Count(); i < count; i++)
            {
                CartItem cartItem = data.CartList[i];
                cartItem.CartToken = data.CartToken;
                //TODO: Check if description is coming from request
                this.inStoreContext.CartItems.Add(cartItem);
                Console.WriteLine("Add item to cart, code: " + cartItem.ProductCode + " - Qty: " + cartItem.Quantity);
            }
            //Try to save the changes
            try
            {
                Console.WriteLine("Cart updated with token: " + data.CartToken+ ". Items in cart: " + data.CartList.Count());
                transaction.Observation = "Cart saved with token: " + data.CartToken + ". Items in cart: " + data.CartList.Count();
                transaction.TransactionResult = 200;//OK
                transaction.TransactionId = data.CartToken;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                Console.WriteLine("End request at " + DateTime.Now);
                return Ok(
                    new
                    {
                        status = "success",
                        message = "Cart saved!",
                        token = data.CartToken,
                        datetime = DateTime.Now,
                        status_code = 00.ToString("D2")
                    });
            }
            catch (Exception ex)
            {
                this.inStoreContext.Database.RollbackTransaction();
                transaction.Observation = "Exception Catched, message: " + ex.InnerException.Message;
                transaction.TransactionResult = 500;
                transaction.TransactionId = data.CartToken;
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                Console.WriteLine("End request at " + DateTime.Now + " with failure.");
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }
        }
    }   

}
