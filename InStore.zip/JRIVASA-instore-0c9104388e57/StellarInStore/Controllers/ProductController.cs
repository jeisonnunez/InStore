﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using StellarInStore.Classes;
using StellarInStore.Models;
using Microsoft.Extensions.Configuration;



namespace StellarInStore.Controllers
{

    [Route("api/product")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IConfiguration configuration;

        public ProductController(IConfiguration config)
        {
            this.configuration = config;
        }

        [HttpGet("[action]/{productCode}/{convertToDefaultCurrency}")]
        public IActionResult ProductBasicInfo(string productCode, bool convertToDefaultCurrency)
        {
            string conString = Utilities.getConnectionStringByWorkingMode(configuration);
            if (conString != null)
            {
                if (!this.ModelState.IsValid)
                {
                    return BadRequest(new { error = true, message = "Bad Request" });
                }

                try
                {
                    var data = DatabaseInterface.sql_query(Product.ProductBasicInfoQueryByCode(Product.productPriceType(conString, productCode), convertToDefaultCurrency, productCode), conString);
                    if (data.Length > 0)
                    {
                        return Ok(new { error = false, data = data, datetime = DateTime.Now });
                    }
                    else
                    {
                        return Ok(new { error = true, message = "No existe el producto", error_code = -1, datetime = DateTime.Now });
                    }
                }
                catch (Exception ex)
                {
                    return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
                }
            }
            else
            {
                return Ok(new { error = true, message = "Bad configuration found, check your appsetting file", error_code = 500, datetime = DateTime.Now });
            }
            
        }
        [HttpGet("[action]/{searchTerm}/{convertToDefaultCurrency}")]
        public IActionResult ProductList(string searchTerm, bool convertToDefaultCurrency)
        {
            string conString = Utilities.getConnectionStringByWorkingMode(configuration);
            if (conString != null)
            {
                if (!this.ModelState.IsValid)
                {
                    return BadRequest(new { error = true, message = "Bad Request" });
                }

                try
                {
                    var data = DatabaseInterface.sql_query(Product.ProductBasicInfoQueryBySearchTerm("n_Precio1", convertToDefaultCurrency, searchTerm), conString);
                    if (data.Length > 0)
                    {
                        return Ok(new { error = false, data = data, datetime = DateTime.Now });
                    }
                    else
                    {
                        return Ok(new { error = true, message = "No existe el producto", error_code = -1, datetime = DateTime.Now });
                    }
                }
                catch (Exception ex)
                {
                    return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
                }
            }
            else
            {
                return Ok(new { error = true, message = "Bad configuration found, check your appsettings file", error_code = 500, datetime = DateTime.Now });
            }            
        }

        [HttpPost("[action]")]
        public IActionResult GetProducts([FromBody] Product product)
        {
            string conString = Utilities.getConnectionStringByWorkingMode(configuration);
            if (conString != null)
            {
                if (!this.ModelState.IsValid)
                {
                    return BadRequest(new { error = true, message = "Bad Request" });
                }

                try
                {
                    string query = Product.ProductBasicInfoQueryMultifilter("n_Precio1", true, product);
                    var data = DatabaseInterface.sql_query(query, conString);
                    if (data.Length > 0)
                    {
                        return Ok(new { error = false, data = data, datetime = DateTime.Now });
                    }
                    else
                    {
                        return Ok(new { error = true, message = "No existe el producto", error_code = -1, datetime = DateTime.Now });
                    }
                }
                catch (Exception ex)
                {
                    return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
                }
            }
            else
            {
                return Ok(new { error = true, message = "Bad configuration found, check your appsettings file", error_code = 500, datetime = DateTime.Now });
            }
        }
    }
}
