﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

using System.Net.Http;
using StellarInStore.Classes;
using StellarInStore.Models;

namespace MVCArrayParametro.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private InStoreContext inStoreContext;

        private readonly IConfiguration configuration;

        public CategoriesController(InStoreContext context, IConfiguration config)
        {
            this.inStoreContext = context;

            this.configuration = config;
        }

        [HttpGet("Categories")]

        public IActionResult GetCategories()
        {
            TransactionsLog transaction = new TransactionsLog();

            try
            {

                string conString = Utilities.getConnectionStringByWorkingMode(configuration);

                if (conString != null)
                {
                    if (!this.ModelState.IsValid)
                    {
                        return BadRequest(new { error = true, message = "Bad Request" });
                    }

                    try
                    {
                        var data = DatabaseInterface.sql_queryJSON(MA_DEPARTAMENTO.CategoriesQuery(), conString);

                        if (data != null)
                        {
                            Console.WriteLine(data);

                            //transaction.Observation = "Found Categories Success";
                            //transaction.TransactionResult = 104; //Revisar
                            //transaction.TransactionId = "2";//Revisar
                            //this.inStoreContext.TransactionsLogs.Add(transaction);
                            //this.inStoreContext.SaveChanges();
                            //this.inStoreContext.Database.CommitTransaction();
                            //this.inStoreContext.Dispose();

                            return Ok(new { error = false, data, datetime = DateTime.Now });
                        }
                        else
                        {
                            //transaction.Observation = "Not Found Categories ";
                            //transaction.TransactionResult = 104; //Revisar
                            //transaction.TransactionId = "2";//Revisar
                            //this.inStoreContext.TransactionsLogs.Add(transaction);
                            //this.inStoreContext.SaveChanges();
                            //this.inStoreContext.Database.CommitTransaction();
                            //this.inStoreContext.Dispose();

                            return Ok(new
                            {
                                status = "error",
                                status_code = -1, //Revisar
                                message = "Not Found Categories",
                                datetime = DateTime.Now
                            });
                            
                        }
                    }
                    catch (Exception ex)
                    {
                        return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
                    }
                }
                else
                {
                    return Ok(new { error = true, message = "Bad configuration found, check your appsettings file", error_code = 500, datetime = DateTime.Now });
                }

                

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception catched");
                Console.WriteLine("Exception Message" + ex.Message);
                Console.WriteLine("InnerException Message" + ex.InnerException.Message);
                transaction.Observation = "Exception catched";
                transaction.TransactionResult = 500;
                transaction.TransactionId = "2";//Revisar
                this.inStoreContext.TransactionsLogs.Add(transaction);
                this.inStoreContext.SaveChanges();
                this.inStoreContext.Database.CommitTransaction();
                this.inStoreContext.Dispose();
                return Ok(new { error = true, message = ex.Message, error_code = ex.HResult.ToString(), datetime = DateTime.Now });
            }

        }

       
    }

    
}
